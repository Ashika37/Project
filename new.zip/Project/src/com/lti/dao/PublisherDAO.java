package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.lti.model.Book;
import com.lti.model.Publisher;
import com.lti.model.Store;

public class PublisherDAO {

	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "tiger";
	private static final String INSERT_PUBLISHER_SQL = "INSERT INTO Publisher VALUES" +"(user_seq.NEXTVAL,?,?,?)";
	private static final String SELECT_PUBLISHER_BY_ID = "select PUBLISHER_CODE,PUBLISHER_ID, PUBLISHER_NAME,EMAIL,WEBSITE from Publisher";
	private static final String SELECT_PUBLISHER_USERS = "select * from Publisher";
	private static final String DELETE_PUBLISHER_SQL = "delete from Publisher where PUBLISHER_ID= ?";
	private static final String UPDATE_PUBLISHER_SQL = "update Publisher set PUBLISHER_NAME = ?";
	public PublisherDAO(){} 

	protected Connection getConnection() {
		Connection connection=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection=DriverManager.getConnection(jdbcURL,jdbcUsername,jdbcPassword);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		return connection;
	}

	public void insertPublisher(Publisher publisher) throws SQLException {
		System.out.println(INSERT_PUBLISHER_SQL);
		 
		try {Connection connection =getConnection();
		PreparedStatement preparedStatement=connection.prepareStatement(INSERT_PUBLISHER_SQL);
		preparedStatement.setString(1,publisher.getPUBLISHER_CODE());
		preparedStatement.setString(2,publisher.getPUBLISHER_NAME());
		preparedStatement.setString(3,publisher.getEMAIL());
		preparedStatement.setString(4,publisher.getWEBSITE());
		System.out.println(preparedStatement);
		preparedStatement.executeUpdate();	
		} catch(SQLException e) {
			printSQLException(e);
		}
	}

	public Publisher selectPublish(int PUBLISHER_ID){
		Publisher publisher = null;
		try{
			Connection connection = getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(SELECT_PUBLISHER_BY_ID);
			preparedStatement.setInt(1,PUBLISHER_ID);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()){
				String PUBLISHER_CODE = rs.getString("PUBLISHER_CODE");
				String PUBLISHER_NAME= rs.getString("PUBLISHER_NAME");
				String EMAIL = rs.getString("EMAIL");
				String WEBSITE = rs.getString("WEBSITE");
				publisher = new Publisher(PUBLISHER_CODE,PUBLISHER_ID,PUBLISHER_NAME,EMAIL,WEBSITE);
				
			
			}
		} catch(SQLException e) {
			printSQLException(e);
		}
		return publisher;
		
			

		}
	public ArrayList<Publisher> selectAllPublisher(){
		ArrayList<Publisher> publisher=new ArrayList<>();
		try{
			Connection connection=getConnection();
			
			PreparedStatement preparedStatement=connection.prepareStatement(SELECT_PUBLISHER_USERS);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()){
			int PUBLISHER_ID = rs.getInt("PUBLISHER_ID");
			String PUBLISHER_CODE = rs.getString("PUBLISHER_CODE");
			String PUBLISHER_NAME= rs.getString("PUBLISHER_NAME");
			String EMAIL = rs.getString("EMAIL");
			String WEBSITE = rs.getString("WEBSITE");
			publisher.add(new Publisher(PUBLISHER_CODE,PUBLISHER_ID,PUBLISHER_NAME,EMAIL,WEBSITE));
		}

	} catch(SQLException e) {
		printSQLException(e);
	}
	return publisher;

		

	}
	public boolean deletePublisher(int PUBLISHER_ID) throws SQLException{
		boolean rowDeleted;
		try(Connection connection=getConnection();
				PreparedStatement statement=connection.prepareStatement(DELETE_PUBLISHER_SQL);) {
				statement.setInt(1,PUBLISHER_ID);
				rowDeleted=statement.executeUpdate() >0;	
	}
		return rowDeleted;

	}

	public boolean updatePublisher(Publisher publisher) throws SQLException {
		boolean rowUpdated;
		try(Connection connection=getConnection();
				PreparedStatement statement=connection.prepareStatement(UPDATE_PUBLISHER_SQL);) {
			
			
			statement.setString(1,publisher.getPUBLISHER_CODE());
			statement.setString(2,publisher.getPUBLISHER_NAME());
			statement.setString(3,publisher.getEMAIL());
			statement.setString(4,publisher.getWEBSITE());
			statement.setInt(5,publisher.getPUBLISHER_ID());
			rowUpdated=statement.executeUpdate() >0;	
		}
		return rowUpdated;
			
		}
	private void printSQLException(SQLException ex){
		ex.printStackTrace();
	}
	
}
