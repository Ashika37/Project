package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.lti.model.Book;

public class BookDAO {
	
	
	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "tiger";
	private static final String INSERT_BOOK_SQL = "INSERT INTO Book VALUES" +"(user_seq.NEXTVAL,?,?,?)";
	private static final String SELECT_BOOK_BY_ID = "select ISBN,BOOK_TITLE, AUTHOR_ID,PUBLISHER_ID from Book";
	private static final String SELECT_BOOK_USERS = "select * from Book";
	private static final String DELETE_BOOK_SQL = "delete from Book where ISBN= ?";
	private static final String UPDATE_BOOK_SQL = "update Book set BOOK_TITLE = ?";
	public BookDAO(){} 

	protected Connection getConnection() {
		Connection connection=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection=DriverManager.getConnection(jdbcURL,jdbcUsername,jdbcPassword);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		return connection;
	}

	public void insertBook(Book book) throws SQLException {
		System.out.println(INSERT_BOOK_SQL);
		 
		try {Connection connection =getConnection();
		PreparedStatement preparedStatement=connection.prepareStatement(INSERT_BOOK_SQL);
		preparedStatement.setString(1,book.getBOOK_TITLE());
		preparedStatement.setString(2,book.getAUTHOR_ID());
		preparedStatement.setString(3,book.getPUBLISHER_ID());
		System.out.println(preparedStatement);
		preparedStatement.executeUpdate();	
		} catch(SQLException e) {
			printSQLException(e);
		}
	}

	public Book selectBook(int ISBN){
		Book book = null;
		try{
			Connection connection = getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(SELECT_BOOK_BY_ID);
			preparedStatement.setInt(1,ISBN);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()){
				String BOOK_TITLE = rs.getString("BOOK_TITLE");
				String AUTHOR_ID= rs.getString("AUTHOR_ID");
				String PUBLISHER_ID = rs.getString("PUBLISHER_ID");
				book = new Book(ISBN,BOOK_TITLE,AUTHOR_ID,PUBLISHER_ID);
				
			
			}
		} catch(SQLException e) {
			printSQLException(e);
		}
		return book;
		
			

		}
	public ArrayList<Book> selectAllBooks(){
		ArrayList<Book> book=new ArrayList<>();
		try{
			Connection connection=getConnection();
			
			PreparedStatement preparedStatement=connection.prepareStatement(SELECT_BOOK_USERS);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()){
			int ISBN = rs.getInt("ISBN");
			String BOOK_TITLE = rs.getString("BOOK_TITLE");
			String AUTHOR_ID= rs.getString("AUTHOR_ID");
			String PUBLISHER_ID = rs.getString("PUBLISHER_ID");
			book.add(new Book(ISBN,BOOK_TITLE,AUTHOR_ID,PUBLISHER_ID));
		}

	} catch(SQLException e) {
		printSQLException(e);
	}
	return book;

		

	}
	public boolean deleteBook(int id) throws SQLException{
		boolean rowDeleted;
		try(Connection connection=getConnection();
				PreparedStatement statement=connection.prepareStatement(DELETE_BOOK_SQL);) {
				statement.setInt(1,id);
				rowDeleted=statement.executeUpdate() >0;	
	}
		return rowDeleted;

	}

	public boolean updateBook(Book book) throws SQLException {
		boolean rowUpdated;
		try(Connection connection=getConnection();
				PreparedStatement statement=connection.prepareStatement(UPDATE_BOOK_SQL);) {
			
			statement.setString(1,book.getBOOK_TITLE());
			statement.setString(2,book.getAUTHOR_ID());
			statement.setString(3,book.getPUBLISHER_ID());
			statement.setInt(4,book.getISBN());
			rowUpdated=statement.executeUpdate() >0;	
		}
		return rowUpdated;
			
		}
	private void printSQLException(SQLException ex){
		ex.printStackTrace();
	}
	
}
