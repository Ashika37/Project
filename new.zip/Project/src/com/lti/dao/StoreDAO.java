package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.lti.model.Store;

public class StoreDAO {

	
	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "tiger";
	private static final String INSERT_STORE_SQL = "INSERT INTO Stores VALUES" +"(user_seq.NEXTVAL,?,?,?)";
	private static final String SELECT_STORE_BY_ID = "select STORE_ID,ADDRESS,CITY,STATE,ZIPCODE from Stores";
	private static final String SELECT_STORE_USERS = "select * from Stores";
	private static final String DELETE_STORE_SQL = "delete from Stores where STORE_ID= ?";
	private static final String UPDATE_STORE_SQL = "update Stores set ADDRESS = ?";
	public StoreDAO(){} 

	protected Connection getConnection() {
		Connection connection=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection=DriverManager.getConnection(jdbcURL,jdbcUsername,jdbcPassword);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		return connection;
	}

	public void insertStore(Store store) throws SQLException {
		System.out.println(INSERT_STORE_SQL);
		 
		try {Connection connection =getConnection();
		PreparedStatement preparedStatement=connection.prepareStatement(INSERT_STORE_SQL);
		preparedStatement.setString(1,store.getADDRESS());
		preparedStatement.setString(2,store.getCITY());
		preparedStatement.setString(3,store.getSTATE());
		preparedStatement.setString(1,store.getZIPCODE());
		System.out.println(preparedStatement);
		preparedStatement.executeUpdate();	
		} catch(SQLException e) {
			printSQLException(e);
		}
	}

	public Store selectStore(int STORE_ID){
		Store store = null;
		try{
			Connection connection = getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(SELECT_STORE_BY_ID);
			preparedStatement.setInt(1,STORE_ID);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()){
				String ADDRESS = rs.getString("ADDRESS");
				String CITY= rs.getString("CITY");
				String STATE = rs.getString("STATE");
				String ZIPCODE = rs.getString("ZIPCODE");
		
				store = new Store(STORE_ID,ADDRESS,CITY,STATE,ZIPCODE);
			}
		} catch(SQLException e) {
			printSQLException(e);
		}
		return store;
}
	
	public ArrayList<Store> selectAllStore(){
		ArrayList<Store> store=new ArrayList<>();
		try{
			Connection connection=getConnection();
			
			PreparedStatement preparedStatement=connection.prepareStatement(SELECT_STORE_USERS);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()){
			int STORE_ID = rs.getInt("STORE_ID");
			String ADDRESS = rs.getString("ADDRESS");
			String CITY= rs.getString("CITY");
			String STATE = rs.getString("STATE");
			String ZIPCODE = rs.getString("ZIPCODE");
			store.add(new Store(STORE_ID,ADDRESS,CITY,STATE,ZIPCODE));
		}

	} catch(SQLException e) {
		printSQLException(e);
	}
	return store;

		

	}
	public boolean deleteStore(int STORE_ID) throws SQLException{
		boolean rowDeleted;
		try(Connection connection=getConnection();
				PreparedStatement statement=connection.prepareStatement(DELETE_STORE_SQL);) {
				statement.setInt(1,STORE_ID);
				rowDeleted=statement.executeUpdate() >0;	
	}
		return rowDeleted;

	}

	public boolean updateStore(Store store) throws SQLException {
		boolean rowUpdated;
		try(Connection connection=getConnection();
				PreparedStatement statement=connection.prepareStatement(UPDATE_STORE_SQL);) {
			statement.setString(1,store.getADDRESS());
			statement.setString(2,store.getCITY());
			statement.setString(3,store.getSTATE());
			statement.setString(1,store.getZIPCODE());
		
			statement.setInt(4,store.getSTORE_ID());
			rowUpdated=statement.executeUpdate() >0;	
		}
		return rowUpdated;
			
		}
	private void printSQLException(SQLException ex){
		ex.printStackTrace();
	}
	
}
