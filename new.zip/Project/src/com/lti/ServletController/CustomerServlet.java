package com.lti.ServletController;

import java.io.IOException
;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.dao.CustomerDAO;
import com.lti.model.Book;
import com.lti.model.Customer;


@WebServlet("/CustomerServlet")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private CustomerDAO customerDAO;
	
    public CustomerServlet() {
        super();
        
    }

    public void init() {
    	customerDAO = new CustomerDAO();
	}
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getServletPath();
		try{
			switch(action){
			case "/new":
				showCustomerForm(request,response);
				break;
			case "/insert":
				insertCustomer(request,response);
				break;
			case "/delete":
				deleteCustomer(request,response);
				break;
			case "/edit":
				CustomerEditForm(request,response);
				break;
			case "/update":
				updateCustomer(request,response);
				break;
			default:
				listCustomer(request,response);
						
			}
		}catch(Exception ex) {
			throw new ServletException(ex);
			
		}
	}


	private void listCustomer(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Customer> customerUser = customerDAO.selectAllCustomer();
		request.setAttribute("customerUser",customerUser);
		RequestDispatcher dispatcher=request.getRequestDispatcher("customer-list.jsp");
		dispatcher.forward(request, response);
		
	}

	private void updateCustomer(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int CUSTOMER_ID = Integer.parseInt(request.getParameter("CUSTOMER_ID"));
		String FIRST_NAME = request.getParameter("FIRST_NAME");
		String LAST_NAME = request.getParameter("LAST_NAME");
		String ADDRESS = request.getParameter("ADDRESS");
		String CITY = request.getParameter("CITY");
		String STATE = request.getParameter("STATE");
		String ZIPCODE = request.getParameter("ZIPCODE");
		Customer customer = new Customer(CUSTOMER_ID,FIRST_NAME,LAST_NAME,ADDRESS,CITY,STATE,ZIPCODE);
		customerDAO.insertCustomer(customer);
		response.sendRedirect("list");
		
	}

	private void CustomerEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int CUSTOMER_ID = Integer.parseInt(request.getParameter("CUSTOMER_ID"));
		Customer existingUser = customerDAO.selectBook(CUSTOMER_ID);
		RequestDispatcher dispatcher=request.getRequestDispatcher("customer-form.jsp");
		request.setAttribute("customer", existingUser);
		dispatcher.forward(request, response);
		
	}

	private void deleteCustomer(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		
		int CUSTOMER_ID = Integer.parseInt(request.getParameter("CUSTOMER_ID"));
		customerDAO.deleteBook(CUSTOMER_ID);
		response.sendRedirect("list");
	}

	private void insertCustomer(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
	
		String FIRST_NAME = request.getParameter("FIRST_NAME");
		String LAST_NAME = request.getParameter("LAST_NAME");
		String ADDRESS = request.getParameter("ADDRESS");
		
		String CITY = request.getParameter("CITY");
		String STATE = request.getParameter("STATE");
		String ZIPCODE = request.getParameter("ZIPCODE");
		Customer newcust = new Customer( FIRST_NAME,LAST_NAME,ADDRESS,CITY,STATE,ZIPCODE);
		customerDAO.insertCustomer(newcust);
		response.sendRedirect("list");
		
	}

	private void showCustomerForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		RequestDispatcher dispatcher=request.getRequestDispatcher("customer-form.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
