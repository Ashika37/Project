package com.lti.ServletController;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.dao.PublisherDAO;
import com.lti.dao.StoreDAO;
import com.lti.model.Publisher;
import com.lti.model.Store;

/**
 * Servlet implementation class PublisherServlet
 */
@WebServlet("/PublisherServlet")
public class PublisherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private PublisherDAO publisherDAO;
	
    public PublisherServlet() {
        super();

    }
    
    public void init() {
    	publisherDAO = new PublisherDAO();
	}
    


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		try{
			switch(action){
			case "/new":
				showPublisherForm(request,response);
				break;
			case "/insert":
				insertPublisher(request,response);
				break;
			case "/delete":
				deletePublisher(request,response);
				break;
			case "/edit":
				PublisherEditForm(request,response);
				break;
			case "/update":
				updatePublisher(request,response);
				break;
			default:
				listPublisher(request,response);
						
			}
		}catch(Exception ex) {
			throw new ServletException(ex);
			
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	private void listPublisher(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Publisher> publisherUser = publisherDAO.selectAllPublisher();
		request.setAttribute("publisherUser",publisherUser);
		RequestDispatcher dispatcher=request.getRequestDispatcher("publisher-list.jsp");
		dispatcher.forward(request, response);
		
	}

	private void updatePublisher(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {

		int PUBLISHER_ID = Integer.parseInt(request.getParameter("PUBLISHER_ID"));
		String PUBLISHER_CODE = request.getParameter("PUBLISHER_CODE");
		String PUBLISHER_NAME = request.getParameter("PUBLISHER_NAME");
		String EMAIL = request.getParameter("EMAIL");
		String WEBSITE = request.getParameter("WEBSITE");
		Publisher publisher = new Publisher(PUBLISHER_CODE,PUBLISHER_ID,PUBLISHER_NAME,EMAIL,WEBSITE);
		publisherDAO.insertPublisher(publisher);
		response.sendRedirect("list");
	}

	private void PublisherEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int PUBLISHER_ID = Integer.parseInt(request.getParameter("PUBLISHER_ID"));
		Publisher existingUser = publisherDAO.selectPublish(PUBLISHER_ID);
		RequestDispatcher dispatcher=request.getRequestDispatcher("publisher-form.jsp");
		request.setAttribute("Publisher", existingUser);
		dispatcher.forward(request, response);
	}

	private void deletePublisher(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int PUBLISHER_ID = Integer.parseInt(request.getParameter("PUBLISHER_ID"));
		publisherDAO.deletePublisher(PUBLISHER_ID);
		response.sendRedirect("list");
	}

	private void insertPublisher(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {

		String PUBLISHER_CODE = request.getParameter("PUBLISHER_CODE");
		String PUBLISHER_NAME = request.getParameter("PUBLISHER_NAME");
		String EMAIL = request.getParameter("EMAIL");
		String WEBSITE = request.getParameter("WEBSITE");
		Publisher newPublisher = new Publisher(PUBLISHER_CODE,PUBLISHER_NAME,EMAIL,WEBSITE);
		publisherDAO.insertPublisher(newPublisher);
		response.sendRedirect("list");
		
	}

	private void showPublisherForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher=request.getRequestDispatcher("publisher-form.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
