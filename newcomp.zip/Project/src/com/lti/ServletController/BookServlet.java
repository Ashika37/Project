package com.lti.ServletController;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.lti.dao.BookDAO;
import com.lti.model.Book;
/**
 * Servlet implementation class BookServlet
 */
@WebServlet("/BookServlet")
public class BookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private BookDAO bookDAO;
	
    public BookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    public void init() {
    	bookDAO = new BookDAO();
	}

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		try{
			switch(action){
			case "/new":
				showBookForm(request,response);
				break;
			case "/insert":
				insertBook(request,response);
				break;
			case "/delete":
				deleteBook(request,response);
				break;
			case "/edit":
				BookEditForm(request,response);
				break;
			case "/update":
				updateBook(request,response);
				break;
			default:
				listBook(request,response);
						
			}
		}catch(Exception ex) {
			throw new ServletException(ex);
			
		}
	}

	private void listBook(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Book> bookUser = bookDAO.selectAllBooks();
		request.setAttribute("bookUser",bookUser);
		RequestDispatcher dispatcher=request.getRequestDispatcher("book-list.jsp");
		dispatcher.forward(request, response);
		
	}

	private void updateBook(HttpServletRequest request, HttpServletResponse response) {
		int ISBN = Integer.parseInt(request.getParameter("ISBN"));
		String BOOK_TITLE = request.getParameter("BOOK_TITLE");
		String AUTHOR_ID = request.getParameter("AUTHOR_ID");
		String PUBLISHER_ID = request.getParameter("PUBLISHER_ID");
		Book book = new Book(ISBN,BOOK_TITLE,AUTHOR_ID,PUBLISHER_ID);
		bookDAO.insertBook(book);
		response.sendRedirect("list");
		
	}

	private void BookEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		int ISBN = Integer.parseInt(request.getParameter("ISBN"));
		Book existingUser = bookDAO.selectBook(ISBN);
		RequestDispatcher dispatcher=request.getRequestDispatcher("book-form.jsp");
		request.setAttribute("user", existingUser);
		dispatcher.forward(request, response);
	}

	private void deleteBook(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException {
	
		int ISBN = Integer.parseInt(request.getParameter("ISBN"));
		bookDAO.deleteBook(ISBN);
		response.sendRedirect("list");
		
	}

	private void insertBook(HttpServletRequest request, HttpServletResponse response) {

		String BOOK_TITLE = request.getParameter("BOOK_TITLE");
		String AUTHOR_ID = request.getParameter("AUTHOR_ID");
		String PUBLISHER_ID = request.getParameter("PUBLISHER_ID");
		Book newbook = new Book(BOOK_TITLE,AUTHOR_ID,PUBLISHER_ID);
		bookDAO.insertBook(newbook);
		response.sendRedirect("list");
	}

	private void showBookForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher=request.getRequestDispatcher("book-form.jsp");
		dispatcher.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
