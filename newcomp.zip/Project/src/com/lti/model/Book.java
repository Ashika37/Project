package com.lti.model;

public class Book {
		private int ISBN;
		private String BOOK_TITLE;
		private AuthorBean AUTHOR_ID;
		private PublisherBean PUBLISHER_ID;
		
		
		public Book(int iSBN, String bOOK_TITLE, AuthorBean aUTHOR_ID, PublisherBean pUBLISHER_ID) {
			super();
			ISBN = iSBN;
			BOOK_TITLE = bOOK_TITLE;
			AUTHOR_ID = aUTHOR_ID;
			PUBLISHER_ID = pUBLISHER_ID;
		}
		
		
		public Book(String bOOK_TITLE, AuthorBean aUTHOR_ID, PublisherBean pUBLISHER_ID) {
			super();
			BOOK_TITLE = bOOK_TITLE;
			AUTHOR_ID = aUTHOR_ID;
			PUBLISHER_ID = pUBLISHER_ID;
		}


		public int getISBN() {
			return ISBN;
		}
		public void setISBN(int iSBN) {
			ISBN = iSBN;
		}
		public String getBOOK_TITLE() {
			return BOOK_TITLE;
		}
		public void setBOOK_TITLE(String bOOK_TITLE) {
			BOOK_TITLE = bOOK_TITLE;
		}
		public AuthorBean getAUTHOR_ID() {
			return AUTHOR_ID;
		}
		public void setAUTHOR_ID(AuthorBean aUTHOR_ID) {
			AUTHOR_ID = aUTHOR_ID;
		}
		public PublisherBean getPUBLISHER_ID() {
			return PUBLISHER_ID;
		}
		public void setPUBLISHER_ID(PublisherBean pUBLISHER_ID) {
			PUBLISHER_ID = pUBLISHER_ID;
		}
	@Override
	public String toString() {
		return "Book [ISBN=" + ISBN + ", BOOK_TITLE=" + BOOK_TITLE + ", AUTHOR_ID=" + AUTHOR_ID + "]";
		}
}