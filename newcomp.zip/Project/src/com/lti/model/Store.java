package com.lti.model;

public class Store {
	private int STORE_ID;
	private String ADDRESS;
	private String CITY;
	private String STATE;
	private String ZIPCODE;
	
	
	public Store(int sTORE_ID, String aDDRESS, String cITY, String sTATE, String zIPCODE) {
		super();
		STORE_ID = sTORE_ID;
		ADDRESS = aDDRESS;
		CITY = cITY;
		STATE = sTATE;
		ZIPCODE = zIPCODE;
	}
	
	
	public Store(String aDDRESS, String cITY, String sTATE, String zIPCODE) {
		super();
		ADDRESS = aDDRESS;
		CITY = cITY;
		STATE = sTATE;
		ZIPCODE = zIPCODE;
	}


	public int getSTORE_ID() {
		return STORE_ID;
	}
	public void setSTORE_ID(int sTORE_ID) {
		STORE_ID = sTORE_ID;
	}
	public String getADDRESS() {
		return ADDRESS;
	}
	public void setADDRESS(String aDDRESS) {
		ADDRESS = aDDRESS;
	}
	public String getCITY() {
		return CITY;
	}
	public void setCITY(String cITY) {
		CITY = cITY;
	}
	public String getSTATE() {
		return STATE;
	}
	public void setSTATE(String sTATE) {
		STATE = sTATE;
	}
	public String getZIPCODE() {
		return ZIPCODE;
	}
	public void setZIPCODE(String zIPCODE) {
		ZIPCODE = zIPCODE;
	}
	@Override
	public String toString() {
		return "StoreBean [STORE_ID=" + STORE_ID + ", ADDRESS=" + ADDRESS + ", CITY=" + CITY + ", STATE=" + STATE
				+ ", ZIPCODE=" + ZIPCODE + "]";
	}

	}
